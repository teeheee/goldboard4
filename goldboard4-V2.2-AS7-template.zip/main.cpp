#include "Goldboard4.h"

Goldboard4 gb;

int main(void)
{
    while (1) 
    {
    }
}

