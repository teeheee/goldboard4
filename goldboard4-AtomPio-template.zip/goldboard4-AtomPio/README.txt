Eine kurze Übersicht über alle Befehle:

Fuses setzen:
> pio run -t fuse

Bootloader übertragen:
> pio run -t uploadboot

Programm compilieren
> pio run

Programm übertragen:
> pio run -t upload

Goldboardlib updaten:
> pio run -t update

Simulator starten:
> pio run -t simulate

Für den simulate Befehl muss der Simulator von https://github.com/teeheee/goldboard4-simulator
heruntergeladen werden und die config.json Datei wie folgt angepasst werden:

{
  "firmware" : ".pioenvs/main/firmware.hex",
  ....
}
