from platformio import util


Import("env")

config = util.load_project_config()

bootloader_port = config.get("env:main", "bootloader_port")
bootloader_protocol = config.get("env:main", "bootloader_protocol")
bootloader_file = config.get("env:main", "bootloader_file")
fuse_high_byte = config.get("env:main", "fuse_high_byte")
fuse_low_byte = config.get("env:main", "fuse_low_byte")

env.Replace(
    SETBOOTLOADER='$UPLOADER -p m32 -v -c '+bootloader_protocol+' -P '+bootloader_port+' -b 19200 '+
    '-U lfuse:w:'+fuse_low_byte+':m '+
    '-U hfuse:w:'+fuse_high_byte+':m '+
    '-U flash:w:"'+bootloader_file+'":i',
)

uploadboot = env.Alias(
    "uploadboot","",
    [
     env.VerboseAction("$SETBOOTLOADER", "Setting fuses and burning bootloader"),
    ])
AlwaysBuild(uploadboot)
