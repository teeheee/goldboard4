/** Project Name: goldboard4_V1_1 
**/

#include "Goldboard4.h"

Goldboard4 gb;

int main(void)
{	
	while(1)
	{
		
	}
}

