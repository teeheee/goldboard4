# Goldboard4 Version 1.10

* [![Actions Status](https://github.com/teeheee/goldboard4/workflows/build/badge.svg)](https://github.com/teeheee/goldboard4/actions)

## Documentation

[Dokumentation](https://github.com/teeheee/goldboard4/wiki)

## Änderungen

Achtung. Die lib ist noch nicht ausgiebig getestet.

Änderungen:
- Button und Leds gehen gleichzeitig
- Maximale Beschleunigung der Motoren kann festgelegt werde
- Servo und Brushless Support
- VL53L0X Support
- U's Sensorring
- i2c Scanner
- Protexpander integriert (Digitalpins gehen jetzt bis 11)
- schnellere IRSensor Abfrage
- PWM f�r PowerPorts
- checkAck Funktion f�r alle i2c libs

