#include "Goldboard4.h"

Goldboard4 gb;

int main(){
	while(1)
	{

	}
	return 0;
}
